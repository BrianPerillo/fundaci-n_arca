
    
    <p>Footer</p>

    </html>
<?php /**PATH C:\xampp\htdocs\fundacion_arca\resources\views/components/footer.blade.php ENDPATH**/ ?>