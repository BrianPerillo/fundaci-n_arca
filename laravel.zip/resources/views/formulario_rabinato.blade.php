

<div class="d-flex justify-content-center"  style="width:50%;margin:auto;" >

    <form action="" class="form-inline" style="width:100%">
    
        <div class="col" style="padding: 0px; box-sizing: border-box">
            <p>Seccion 1</p>

            <div class="form-group">

                <div class="col-sm-12 col-lg-6 col-xl-3 p-3" style="text-align: center">
                    <label style="display:block;color:grey" for="nombre">Nombre
                        <input id="nombre" class="form-control" type="text" style="min-width:100%;max-width:100%" value="" placeholder="1">
                    </label>
                </div>

                <div class="col-sm-12 col-lg-6 col-xl-6 p-3" style="text-align: center">
                    <label style="display:block;color:grey" for="nombre">Apellido
                        <input class="form-control" type="text" style="min-width:100%;max-width:100%" value="" placeholder="2">
                    </label>
                </div>

                <div class="col-sm-12 col-lg-6 col-xl-3 p-3" style="text-align: center">
                    <label style="display:block;color:grey" for="nombre">DNI
                        <input class="form-control" type="text"style="min-width:100%;max-width:100%" value="" placeholder="3">
                    </label>
                </div>
        
                <div class="col-sm-12 col-lg-6 col-xl-4 p-3" style="text-align: center">
                    <label style="display:block;color:grey" for="nombre">Apellido
                        <input class="form-control" style="min-width:100%;max-width:100%" type="text" value="" placeholder="4">
                    </label>
                </div>

                <div class="col-sm-12 col-lg-6 col-xl-4 p-3" style="text-align: center">
                    <label style="display:block;color:grey" for="nombre">Apellido
                        <input class="form-control" style="min-width:100%;max-width:100%" type="text" value="" placeholder="5">
                    </label>
                </div>

                <div class="col-sm-12 col-lg-6 col-xl-4 p-3" style="text-align: center">
                    <label style="display:block;color:grey" for="nombre">Apellido
                        <input class="form-control" style="min-width:100%;max-width:100%" type="text" value="" placeholder="6">
                    </label>
                </div>
                
                <div class="col-sm-12 col-lg-6 col-xl-4 p-3" style="text-align: center">
                    <label style="display:block;color:grey" for="nombre">Apellido
                        <input class="form-control" style="min-width:100%;max-width:100%" type="text" value="" placeholder="7">
                    </label>
                </div>
                

            </div>

            <p>Sección 2</p>

            <div class="form-group">

                <div class="col mb-5 ml-1 mr-1" style="text-align: center">
                    <input class="form-control" style="min-width:100%" type="text" value="" placeholder="8">
                </div>

                <div class="col mb-5 ml-1 mr-1" style="text-align: center">
                    <input class="form-control" type="text" style="min-width:100%"   value="" placeholder="9">
                </div>

                <div class="col mb-5 ml-1 mr-1" style="text-align: center">
                    <input class="form-control" type="text" style="min-width:100%"   value="" placeholder="10">
                </div>
        
                <div class="col mb-5 ml-1 mr-1" style="text-align: center">
                    <input class="form-control" style="min-width:100%"  type="text" value="" placeholder="11">
                </div>

                <div class="col mb-5 ml-1 mr-1" style="text-align: center">
                    <input class="form-control" style="min-width:100%"  type="text" value="" placeholder="12">
                </div>

                <div class="col mb-5 ml-1 mr-1" style="text-align: center">
                    <input class="form-control" style="min-width:100%"  type="text" value="" placeholder="13">
                </div>
                
                <div class="col mb-5 ml-1 mr-1" style="text-align: center">
                    <input class="form-control" style="min-width:100%" type="text" value="" placeholder="14">
                </div>

                <div class="col mb-5 ml-1 mr-1" style="text-align: center">
                    <input class="form-control" style="min-width:100%" type="text" value="" placeholder="14">
                </div>
          
                <div class="col mb-5 ml-1 mr-1" style="text-align: center">
                    <input class="form-control" style="min-width:100%" type="text" value="" placeholder="14">
                </div>

                <div class="col mb-5 ml-1 mr-1" style="text-align: center">
                    <input class="form-control" style="min-width:100%" type="text" value="" placeholder="14">
                </div>

            </div>


            <div class="form-group">
                <div class="col mb-5 mr-1" style="text-align: center">
                    <button class="btn btn-primary float-right">Enviar</button>
                </div>
            </div>
        
        </div>

    </form>

</div>