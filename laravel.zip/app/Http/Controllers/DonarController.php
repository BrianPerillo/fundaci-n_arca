<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DonarController extends Controller
{
    
    function show(){

        return view('donation');
        
    }

}
