<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LineasAccionController extends Controller
{
    
    public function show(){

        return view('lineas_accion');

    }

}
